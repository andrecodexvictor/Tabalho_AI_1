import pytest
import os
from rocket_assistant import RocketAssistant
import speech_recognition as sr
import wave
import numpy as np

class TestRocketAssistant:
    @pytest.fixture
    def assistant(self):
        return RocketAssistant()

    def create_test_audio(self, filename, text):
        """Create a test audio file with text-to-speech (mock implementation)"""
        # This is a mock implementation - in real testing you would need actual audio files
        duration = 3  # seconds
        sample_rate = 16000
        t = np.linspace(0, duration, int(sample_rate * duration))
        audio_data = np.sin(2 * np.pi * 440 * t)  # 440 Hz sine wave
        
        with wave.open(filename, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes((audio_data * 32767).astype(np.int16).tobytes())

    def test_command_recognition(self, assistant):
        """Test command recognition from text"""
        commands = [
            ("iniciar decolagem", "Iniciando decolagem. Preparando contagem regressiva."),
            ("liberar primeiro estágio", "Liberando estágio 1. Estágio 1 liberado com sucesso."),
            ("liberar segundo estágio", "Liberando estágio 2. Estágio 2 liberado com sucesso."),
            ("pousar booster", "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso."),
            ("liberar satélite", "Satélite liberado e pronto para uso.")
        ]
        
        for command, expected_response in commands:
            response = assistant.process_command(command)
            assert response == expected_response

    def test_audio_processing(self, assistant, tmp_path):
        """Test processing of recorded audio"""
        test_file = tmp_path / "test_audio.wav"
        self.create_test_audio(str(test_file), "iniciar decolagem")
        
        response = assistant.process_recorded_audio(str(test_file))
        assert response is not None

    def test_invalid_command(self, assistant):
        """Test response to invalid command"""
        response = assistant.process_command("comando inválido")
        assert "não reconhecido" in response.lower()

if __name__ == "__main__":
    pytest.main([__file__])