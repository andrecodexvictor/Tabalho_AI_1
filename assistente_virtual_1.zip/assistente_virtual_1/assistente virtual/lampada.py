import serial
from time import sleep

PORTA_LAMPADA = "/dev/ttyACM0"

LIGAR = b'L'
DESLIGAR = b'D'

def iniciar_lampada(porta = PORTA_LAMPADA):
    global porta_lampada
    
    porta_lampada = None
    try:
        porta_lampada = serial.Serial(port= porta, baudrate= 9600, bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)
    except Exception as e:
        print(f"erro iniciando lâmpada: {str(e)}")
    
    return porta_lampada is not None

def atuar_sobre_lampada(acao, objeto):
    global porta_lampada

    if acao in ["ligar", "acender"] and objeto == "lâmpada":
        print("ligando lâmpada")

        porta_lampada.write(LIGAR)
    elif acao in ["desligar", "apagar"] and objeto == "lâmpada":
        print("desligando lâmpada")

        porta_lampada.write(DESLIGAR)