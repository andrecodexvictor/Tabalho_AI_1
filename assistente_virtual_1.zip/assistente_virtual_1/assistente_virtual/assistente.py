from inicializador_modelos import *
from transcritor import *
from flask import Flask, request, jsonify, send_from_directory
from threading import Thread
from nltk import word_tokenize, corpus
import secrets
import pyaudio
import wave
import json
import os
import time

AMOSTRAS = 1024
FORMATO = pyaudio.paInt16
CANAIS = 1
TEMPO_DE_GRAVACAO = 5
CAMINHO_AUDIO_FALA = "temp/"
IDIOMA_CORPUS = "portuguese"
CONFIGURACAO = "config.json"

class RocketAssistant:
    def __init__(self):
        self.current_stage = 0
        self.is_launched = False
        self.satellite_deployed = False
        
    def countdown(self):
        for i in range(10, -1, -1):
            print(f"{i}...")
            time.sleep(1)
        print("Decolagem!")
        self.is_launched = True
        return "Decolagem concluída!"

    def handle_command(self, command):
        if "iniciar decolagem" in command.lower():
            return self.countdown()
        
        elif "liberar primeiro estágio" in command.lower():
            if not self.is_launched:
                return "Erro: Foguete ainda não decolou"
            self.current_stage = 1
            return "Liberando estágio 1. Estágio 1 liberado com sucesso."
            
        elif "liberar segundo estágio" in command.lower():
            if self.current_stage != 1:
                return "Erro: Primeiro estágio não liberado"
            self.current_stage = 2
            return "Liberando estágio 2. Estágio 2 liberado com sucesso."
            
        elif "pousar booster" in command.lower():
            if self.current_stage < 1:
                return "Erro: Nenhum estágio foi liberado ainda"
            return "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso."
            
        elif "liberar satélite" in command.lower():
            if self.current_stage != 2:
                return "Erro: Segundo estágio não liberado"
            self.satellite_deployed = True
            return "Satélite liberado e pronto para uso."
            
        return "Comando não reconhecido"

def processar_transcricao(transcricao, palavras_de_parada):
    comando = []
    tokens = word_tokenize(transcricao.lower())
    for token in tokens:
        if token not in palavras_de_parada:
            comando.append(token)
    return " ".join(comando)

def inicializar_assistente():
    # Carrega configurações iniciais
    dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
    
    # Inicializa o modelo de reconhecimento de fala
    iniciado, processador, modelo = iniciar_modelo(MODELOS[0], dispositivo)
    
    if not iniciado:
        raise Exception("Falha ao inicializar modelo de reconhecimento de fala")
        
    return {
        "dispositivo": dispositivo,
        "processador": processador, 
        "modelo": modelo
    }

# Modificar a criação do serviço Flask
servico = Flask("rocket_assistant", static_folder="public")
servico.config.update(inicializar_assistente())

# Garantir que o diretório de áudio temporário existe
os.makedirs(CAMINHO_AUDIO_FALA, exist_ok=True)

# Carregar stopwords
palavras_de_parada = set(corpus.stopwords.words(IDIOMA_CORPUS))
servico.config["palavras_de_parada"] = palavras_de_parada

rocket = RocketAssistant()
@servico.route('/')
def serve_index():
    return send_from_directory('public', 'index.html')

@servico.post("/reconhecer_comando")
def reconhecer_comando():
    if 'audio' not in request.files:
        return jsonify({"erro": "Nenhum arquivo de áudio encontrado"}), 400
    
    arquivo = request.files['audio']
    caminho_arquivo = os.path.join(CAMINHO_AUDIO_FALA, f"{secrets.token_hex(32).lower()}.wav")
    arquivo.save(caminho_arquivo)

    try:
        transcricao = transcrever_fala(servico.config["dispositivo"], 
                                     carregar_fala(caminho_arquivo), 
                                     servico.config["modelo"], 
                                     servico.config["processador"])

        comando = processar_transcricao(transcricao, servico.config["palavras_de_parada"])
        resposta = rocket.handle_command(comando)

        return jsonify({
            'transcription': transcricao,
            'response': resposta
        })
    except Exception as e:
        print("Erro ao processar o áudio:", e)
        return jsonify({"erro": "Erro ao processar o áudio"}), 500
    finally:
        if os.path.exists(caminho_arquivo):
            os.remove(caminho_arquivo)
