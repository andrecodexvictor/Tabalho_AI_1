from inicializador_modelos import *
from transcritor import *
import numpy as np
from nltk import word_tokenize, corpus
import json
import os
import torch
from atuadores.decolagem import decolagem_atuador
from atuadores.liberar import liberar_atuador
from atuadores.pousar import pousar_atuador
from atuadores.satelite import liberar_satelite_atuador

# Configurações de áudio
AMOSTRAS = 1024
TAXA_AMOSTRAGEM = 16_000
FORMATO = pyaudio.paInt16
CANAIS = 1
TEMPO_ESPERA_SILENCIO = 1.0
CAMINHO_AUDIO_FALA = "audios"
CONFIGURACAO = "config.json"
SILENCIO_LIMIAR = 500

def iniciar(dispositivo):
    gravador = pyaudio.PyAudio()
    assistente_iniciado, processador, modelo = iniciar_modelo(MODELOS[0], dispositivo)
    palavras_de_parada, acoes = None, None
    if assistente_iniciado:
        palavras_de_parada = corpus.stopwords.words("portuguese")
        with open(CONFIGURACAO, "r") as arquivo_configuracao:
            configuracao = json.load(arquivo_configuracao)
            acoes = configuracao["acoes"]
    return assistente_iniciado, processador, modelo, gravador, palavras_de_parada, acoes

def validar_comando(acoes, comando, palavras_de_parada, lista):
    texto = remover_comando_wake_up(comando)
    comando_separado = separar_comando_e_remover_palavras_parada(texto, palavras_de_parada)
    
    for acao in acoes:
        if acao["comando"] == comando_separado[0]:
            executar_acao(acao, get_objeto_comando(texto), lista)

class Foguete:
    def __init__(self):
        self.is_launched = False
        self.current_stage = 0
        self.satellite_deployed = False

def executar_acao(foguete, acao, comando):
    if acao["identificador"] == "decolagem":
        return decolagem_atuador(foguete)
    elif acao["identificador"] == "estagio1":
        return liberar_atuador(foguete, 1)
    elif acao["identificador"] == "estagio2":
        return liberar_atuador(foguete, 2)
    elif acao["identificador"] == "pouso":
        return pousar_atuador(foguete)
    elif acao["identificador"] == "satelite":
        return liberar_satelite_atuador(foguete)
    return "Ação não reconhecida."

if __name__ == "__main__":
    dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
    foguete = Foguete()  # Instância do foguete
    iniciado, processador, modelo, gravador, palavras_parada, acoes = iniciar(dispositivo)
    if iniciado:
        while True:
            for acao in acoes:
                if acao["comando"] in comando:
                    resposta = executar_acao(foguete, acao, comando)
                    print(resposta)
                    break

