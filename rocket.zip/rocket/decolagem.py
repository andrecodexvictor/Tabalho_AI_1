def decolagem_atuador(foguete):
    if foguete.is_launched:
        return "Erro: O foguete já foi lançado."
    foguete.is_launched = True
    return "Iniciando decolagem. Preparando contagem regressiva..."
