def pousar_atuador(foguete):
    if foguete.current_stage < 1:
        return "Erro: Nenhum estágio foi liberado ainda."
    return "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso."
