def liberar_satelite_atuador(foguete):
    if foguete.current_stage != 2:
        return "Erro: Segundo estágio não liberado."
    if foguete.satellite_deployed:
        return "Erro: Satélite já foi liberado."
    foguete.satellite_deployed = True
    return "Satélite liberado e pronto para uso."
